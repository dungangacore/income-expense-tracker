# Income Expense Tracker

Basit bir CLI uygulamasıyla gelir ve giderleri takip edin.

## Kullanım
Uygulamayı başlatmak için:

```
python main.py
```

## Özellikler
- Gelir ve gider ekleme
- Toplam bakiye görüntüleme
- Aylık özet alma
- CSV'ye dışa aktarma